./raytracer1c example1.txt
./raytracer1c example2.txt
./raytracer1c example3.txt
./raytracer1c example4.txt
./raytracer1c example5.txt
./raytracer1c example6.txt
./raytracer1c example7.txt