./raytracer1b example1.txt
./raytracer1b example2.txt
./raytracer1b example3.txt
./raytracer1b example4.txt
./raytracer1b example5.txt
./raytracer1b example6.txt